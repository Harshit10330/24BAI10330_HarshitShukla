package com.hostel.management.controller;
import java.util.List;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hostel.management.model.Staff;
import com.hostel.management.service.StaffService;
import jakarta.validation.Valid;
@RestController
@RequestMapping("/api/staff")
public class StaffController {
    private final StaffService staffService;
    public StaffController(StaffService staffService) {
        this.staffService = staffService;
    }

    @PostMapping
    public Staff createStaff(@Valid @RequestBody Staff staff) {
        return staffService.saveStaff(staff);
    }

    @GetMapping
    public List<Staff> getAllStaff() {
        return staffService.getAllStaff();
    }

    @PutMapping("/{id}")
    public Staff updateStaff(@PathVariable String id,
            @Valid @RequestBody Staff staff) {
        return staffService.updateStaff(id, staff);
    }

    @DeleteMapping("/{id}")
    public String deleteStaff(@PathVariable String id) {
        staffService.deleteStaff(id);
        return "Staff deleted successfully";
    }
}
