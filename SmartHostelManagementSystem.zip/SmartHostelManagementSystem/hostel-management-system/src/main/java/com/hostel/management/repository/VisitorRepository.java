package com.hostel.management.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.hostel.management.model.Visitor;

public interface VisitorRepository extends MongoRepository<Visitor, String> {

}