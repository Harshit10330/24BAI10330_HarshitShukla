package com.hostel.management.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hostel.management.model.Student;
import com.hostel.management.repository.StudentRepository;

@Service
public class StudentService {

    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    // CREATE
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    // READ
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // UPDATE
    public Student updateStudent(String id, Student updatedStudent) {
        updatedStudent.setId(id);
        return studentRepository.save(updatedStudent);
    }

    // DELETE
    public void deleteStudent(String id) {
        studentRepository.deleteById(id);
    }
}