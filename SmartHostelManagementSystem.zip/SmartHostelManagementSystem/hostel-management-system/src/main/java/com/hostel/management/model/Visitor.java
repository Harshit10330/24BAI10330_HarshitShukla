package com.hostel.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "visitors")
public class Visitor {

    @Id
    private String id;

    private String name;
    private String phoneNumber;
    private String relationToStudent;
    private String visitDate;

    public Visitor() {
    }

    public Visitor(String id, String name, String phoneNumber, String relationToStudent, String visitDate) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.relationToStudent = relationToStudent;
        this.visitDate = visitDate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRelationToStudent() {
        return relationToStudent;
    }

    public void setRelationToStudent(String relationToStudent) {
        this.relationToStudent = relationToStudent;
    }

    public String getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(String visitDate) {
        this.visitDate = visitDate;
    }
}