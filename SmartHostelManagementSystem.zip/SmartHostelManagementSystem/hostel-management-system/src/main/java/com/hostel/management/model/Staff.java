package com.hostel.management.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
@Document(collection = "staff")
public class Staff {
    @Id
    private String id;
    @NotBlank(message = "Staff name cannot be empty")
    private String name;
    @NotBlank(message = "Designation cannot be empty")
    private String designation;
    @Pattern(regexp = "^[0-9]{10}$",
            message = "Phone number must be exactly 10 digits")
    private String phoneNumber;
    @Positive(message = "Salary must be positive")
    private double salary;

    public Staff() {
    }

    public Staff(String id, String name, String designation, String phoneNumber, double salary) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        this.phoneNumber = phoneNumber;
        this.salary = salary;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}