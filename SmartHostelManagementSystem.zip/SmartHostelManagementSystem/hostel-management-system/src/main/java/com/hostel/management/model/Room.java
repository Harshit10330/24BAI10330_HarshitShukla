package com.hostel.management.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
@Document(collection = "rooms")
public class Room {
    @Id
    private String id;
    public Room() {
    }
    public Room(String id, String roomNumber, Integer capacity, Boolean available) {
		super();
		this.id = id;
		this.roomNumber = roomNumber;
		this.capacity = capacity;
		this.available = available;
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public Boolean getAvailable() {
		return available;
	}

	public void setAvailable(Boolean available) {
		this.available = available;
	}

	@NotBlank(message = "Room number cannot be empty")
	private String roomNumber;

	@NotNull(message = "Capacity cannot be empty")
	@Min(value = 1, message = "Capacity must be at least 1")
	private Integer capacity;

	@NotNull(message = "Availability cannot be empty")
	private Boolean available;

}