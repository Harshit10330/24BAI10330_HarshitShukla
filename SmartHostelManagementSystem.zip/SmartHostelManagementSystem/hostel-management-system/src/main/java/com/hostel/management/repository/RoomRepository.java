package com.hostel.management.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hostel.management.model.Room;

public interface RoomRepository extends MongoRepository<Room, String> {

}