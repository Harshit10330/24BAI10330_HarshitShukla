package com.hostel.management.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hostel.management.model.Staff;
import com.hostel.management.repository.StaffRepository;

@Service
public class StaffService {

    private final StaffRepository staffRepository;

    public StaffService(StaffRepository staffRepository) {
        this.staffRepository = staffRepository;
    }

    public Staff saveStaff(Staff staff) {
        return staffRepository.save(staff);
    }

    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    public Staff updateStaff(String id, Staff updatedStaff) {
        updatedStaff.setId(id);
        return staffRepository.save(updatedStaff);
    }

    public void deleteStaff(String id) {
        staffRepository.deleteById(id);
    }
}