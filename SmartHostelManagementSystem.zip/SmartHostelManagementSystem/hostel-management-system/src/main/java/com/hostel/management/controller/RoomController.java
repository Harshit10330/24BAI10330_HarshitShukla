package com.hostel.management.controller;
import jakarta.validation.Valid;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hostel.management.model.Room;
import com.hostel.management.service.RoomService;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    // CREATE
    @PostMapping
    public Room createRoom(@Valid @RequestBody Room room) {
        return roomService.saveRoom(room);
    }

    // READ
    @GetMapping
    public List<Room> getAllRooms() {
        return roomService.getAllRooms();
    }

    // UPDATE
    @PutMapping("/{id}")
    public Room updateRoom(@PathVariable String id,
            @Valid @RequestBody Room room) {
        return roomService.updateRoom(id, room);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteRoom(@PathVariable String id) {
        roomService.deleteRoom(id);
        return "Room deleted successfully";
    }
}