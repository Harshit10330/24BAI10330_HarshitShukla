package com.hostel.management.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hostel.management.model.Room;
import com.hostel.management.repository.RoomRepository;

@Service
public class RoomService {

    private final RoomRepository roomRepository;

    public RoomService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    // CREATE
    public Room saveRoom(Room room) {
        return roomRepository.save(room);
    }

    // READ
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    // UPDATE
    public Room updateRoom(String id, Room updatedRoom) {
        updatedRoom.setId(id);
        return roomRepository.save(updatedRoom);
    }

    // DELETE
    public void deleteRoom(String id) {
        roomRepository.deleteById(id);
    }
}