package com.hostel.management.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hostel.management.model.Staff;

public interface StaffRepository extends MongoRepository<Staff, String> {

}