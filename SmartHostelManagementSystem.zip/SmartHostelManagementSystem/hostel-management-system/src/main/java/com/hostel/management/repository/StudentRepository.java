package com.hostel.management.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hostel.management.model.Student;

public interface StudentRepository extends MongoRepository<Student, String> {

}