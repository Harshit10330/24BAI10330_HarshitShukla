package com.hostel.management.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hostel.management.model.Visitor;
import com.hostel.management.repository.VisitorRepository;

@Service
public class VisitorService {

    private final VisitorRepository visitorRepository;

    public VisitorService(VisitorRepository visitorRepository) {
        this.visitorRepository = visitorRepository;
    }

    public Visitor saveVisitor(Visitor visitor) {
        return visitorRepository.save(visitor);
    }

    public List<Visitor> getAllVisitors() {
        return visitorRepository.findAll();
    }

    public Visitor updateVisitor(String id, Visitor updatedVisitor) {
        updatedVisitor.setId(id);
        return visitorRepository.save(updatedVisitor);
    }

    public void deleteVisitor(String id) {
        visitorRepository.deleteById(id);
    }
}