# Smart Hostel Management System

## Project Overview

The Smart Hostel Management System is a backend application developed using **Spring Boot** and **MongoDB** to efficiently manage hostel operations. The system provides RESTful APIs for managing rooms, students, staff members, and visitors. It follows a layered architecture consisting of Controller, Service, Repository, and Model layers.

---

## Features

### Room Management

* Add new rooms
* View all rooms
* Update room details
* Delete rooms
* Validate room information before storing

### Student Management

* Add students
* View all students
* Update student information
* Delete student records
* Assign students to hostel rooms using MongoDB `@DBRef`

### Staff Management

* Add staff members
* View staff details
* Update staff information
* Delete staff records
* Validate staff information before storing

### Visitor Management

* Add visitor details
* View visitor records
* Update visitor information
* Delete visitor records

---

## Technologies Used

* Java 25
* Spring Boot 4.1.0
* MongoDB
* Spring Data MongoDB
* Maven
* Postman
* MongoDB Compass
* Eclipse IDE

---

## Project Structure

```text
src/main/java
├── com.hostel.management
│   ├── HostelManagementSystemApplication.java
│
├── com.hostel.management.controller
│   ├── RoomController.java
│   ├── StudentController.java
│   ├── StaffController.java
│   └── VisitorController.java
│
├── com.hostel.management.model
│   ├── Room.java
│   ├── Student.java
│   ├── Staff.java
│   └── Visitor.java
│
├── com.hostel.management.repository
│   ├── RoomRepository.java
│   ├── StudentRepository.java
│   ├── StaffRepository.java
│   └── VisitorRepository.java
│
└── com.hostel.management.service
    ├── RoomService.java
    ├── StudentService.java
    ├── StaffService.java
    └── VisitorService.java
```

---

## API Endpoints

### Room APIs

| Method | Endpoint          |
| ------ | ----------------- |
| POST   | `/api/rooms`      |
| GET    | `/api/rooms`      |
| PUT    | `/api/rooms/{id}` |
| DELETE | `/api/rooms/{id}` |

### Student APIs

| Method | Endpoint             |
| ------ | -------------------- |
| POST   | `/api/students`      |
| GET    | `/api/students`      |
| PUT    | `/api/students/{id}` |
| DELETE | `/api/students/{id}` |

### Staff APIs

| Method | Endpoint          |
| ------ | ----------------- |
| POST   | `/api/staff`      |
| GET    | `/api/staff`      |
| PUT    | `/api/staff/{id}` |
| DELETE | `/api/staff/{id}` |

### Visitor APIs

| Method | Endpoint             |
| ------ | -------------------- |
| POST   | `/api/visitors`      |
| GET    | `/api/visitors`      |
| PUT    | `/api/visitors/{id}` |
| DELETE | `/api/visitors/{id}` |

---

## Validation Implemented

### Room Validation

* Room number cannot be empty
* Capacity must be at least 1
* Availability status cannot be null

### Staff Validation

* Staff name cannot be empty
* Designation cannot be empty
* Phone number must contain exactly 10 digits
* Salary must be positive

---

## Database Configuration

Update the `application.properties` file:

```properties
spring.application.name=hostel-management-system
spring.data.mongodb.uri=mongodb://localhost:27017/hostel_db
```

---

## How to Run the Project

1. Start MongoDB Server.
2. Import the project into Eclipse.
3. Update Maven dependencies.
4. Run `HostelManagementSystemApplication.java`.
5. Use Postman to test the APIs.

---

## API Testing

All APIs have been tested using Postman, and MongoDB Compass was used to verify database operations.

---

## Author

**Harshit Shukla**
VIT Bhopal University

---

## Conclusion

The Smart Hostel Management System demonstrates the implementation of RESTful APIs using Spring Boot and MongoDB. The project follows a clean layered architecture and incorporates validation to ensure data integrity, providing an efficient backend solution for hostel management.
